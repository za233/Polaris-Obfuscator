const char* question() {
  return "What do you get if you multiply six by nine?";
}
