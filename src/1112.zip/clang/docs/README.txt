See llvm/docs/README.txt
