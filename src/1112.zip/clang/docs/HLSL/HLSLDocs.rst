.. title:: Clang HLSL Documentation

.. toctree::
   :maxdepth: 1

   HLSLSupport

HLSL Design and Implementation
==============================

.. toctree::
   :maxdepth: 1

   HLSLIRReference
   ResourceTypes
   EntryFunctions
